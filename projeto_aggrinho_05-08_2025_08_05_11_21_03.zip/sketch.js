function setup() {
createCanvas(600, 400);
textFont("Arial");
inicializarTratores();
inicializarMilhos();
tempoRestante = tempoJogo;
botaoComo = new Botao("Como jogar", width / 2 - 75, 200, 150, 40);
botaoJogar = new Botao("Jogar", width / 2 - 75, 250, 150, 40);
botaoVoltar = new Botao("Voltar", width / 2 - 50, 330, 100, 35);
}
let tela = "inicio";
let tempoJogo = 30;
let tempoRestante;
let trator1, trator2;
let milhos = [];
let totalMilhos = 15;
let vencedor = "";
let botaoComo, botaoJogar, botaoVoltar;

function draw() {
background("#3eae3a"); // VERDE mantido!
if (tela === "inicio") telaInicio();
else if (tela === "como") telaComo();
else if (tela === "jogo") telaJogo();
else if (tela === "fim") telaFim();
}

function telaInicio() {
fill(0);
textAlign(CENTER, CENTER);
textSize(32);
text("Jogo dos Tratores", width / 2, 90);
botaoComo.mostra();
botaoJogar.mostra();
}

function telaComo() {
fill(0);
textAlign(CENTER, TOP);
textSize(22);
text("Como Jogar", width / 2, 40);

textSize(14);
textAlign(CENTER);
text(
"2 jogadores competem!\n\n- Colete mais milhos que o adversário em " +
tempoJogo +
" segundos.\n\n- Jogador 1: setas ←↑↓→\n- Jogador 2: W A S D\n\n- Cada milho vale 1 ponto.\n- O trator não pode sair da tela.",
width / 2,
90
);
botaoVoltar.mostra();
}

function telaFim() {
fill(0);
textAlign(CENTER, CENTER);
textSize(26);
text("Fim de Jogo!", width / 2, 80);
textSize(16);
text(
"Vermelho: " +
trator1.pontos +
" | Azul: " +
trator2.pontos +
"\n" +
vencedor,
width / 2,
150
);
botaoVoltar.mostra();
}

function telaJogo() {
fill(0);
textAlign(CENTER, CENTER);
textSize(16);
text("Tempo: " + tempoRestante + " | Vermelho: " + trator1.pontos + " | Azul: " + trator2.pontos, width / 2, 15);


for (let milho of milhos) {
if (!milho.coletado) milho.mostra();
}

trator1.mostra();
trator2.mostra();
trator1.movimenta();
trator2.movimenta();

for (let milho of milhos) {
if (!milho.coletado && trator1.colide(milho)) {
milho.coletado = true;
trator1.pontos++;
milho.reaparecer();
} else if (!milho.coletado && trator2.colide(milho)) {
milho.coletado = true;
trator2.pontos++;
milho.reaparecer();
}
}

// TEMPO
if (frameCount % 60 === 0 && tempoRestante > 0) {
tempoRestante--;
if (tempoRestante === 0) {
definirVencedor();
tela = "fim";
}
}
}

function inicializarTratores() {
trator1 = new Trator(60, height / 2, color(200, 0, 0), "setas");
trator2 = new Trator(width - 60, height / 2, color(0, 0, 200), "wasd");
}

function inicializarMilhos() {
milhos = [];
for (let i = 0; i < totalMilhos; i++) {
let x = random(50, width - 50);
let y = random(60, height - 40);
milhos.push(new Milho(x, y));
}
}

function definirVencedor() {
if (trator1.pontos > trator2.pontos) vencedor = "Vencedor: Vermelho!";
else if (trator2.pontos > trator1.pontos) vencedor = "Vencedor: Azul!";
else vencedor = "Empate!";
}

class Trator {
constructor(x, y, cor, controle) {
this.x = x;
this.y = y;
this.cor = cor;
this.controle = controle;
this.tam = 30;
this.vel = 3;
this.pontos = 0;
this.dx = 0;
this.dy = 0;
}
mostra() {
push();
translate(this.x, this.y);
fill(this.cor);
rect(-this.tam / 2, -this.tam / 2, this.tam, this.tam);
fill(50);
ellipse(-this.tam / 3, this.tam / 2, 10, 10);
ellipse(this.tam / 3, this.tam / 2, 10, 10);
pop();
}
movimenta() {
this.dx = 0;
this.dy = 0;
if (this.controle === "setas") {
if (keyIsDown(LEFT_ARROW)) this.dx = -this.vel;
if (keyIsDown(RIGHT_ARROW)) this.dx = this.vel;
if (keyIsDown(UP_ARROW)) this.dy = -this.vel;
if (keyIsDown(DOWN_ARROW)) this.dy = this.vel;
} else if (this.controle === "wasd") {
if (keyIsDown(65)) this.dx = -this.vel; // A
if (keyIsDown(68)) this.dx = this.vel; // D
if (keyIsDown(87)) this.dy = -this.vel; // W
if (keyIsDown(83)) this.dy = this.vel; // S
}
this.x = constrain(this.x + this.dx, this.tam / 2, width - this.tam / 2);
this.y = constrain(this.y + this.dy, 25 + this.tam / 2, height - this.tam / 2);
}
colide(milho) {
let d = dist(this.x, this.y, milho.x, milho.y);
return d < this.tam / 2 + milho.tam / 2;
}
}

class Milho {
constructor(x, y) {
this.x = x;
this.y = y;
this.tam = 16;
this.coletado = false;
}
mostra() {
push();
translate(this.x, this.y);
fill(230, 230, 0);
ellipse(0, 0, this.tam, this.tam);
pop();
}
reaparecer() {
this.x = random(50, width - 50);
this.y = random(60, height - 40);
this.coletado = false;
}
}

class Botao {
constructor(texto, x, y, w, h) {
this.texto = texto;
this.x = x;
this.y = y;
this.w = w;
this.h = h;
}
mostra() {
fill(255); // branco
noStroke();
rect(this.x, this.y, this.w, this.h);
fill(0); // preto
textAlign(CENTER, CENTER);
textSize(16);
text(this.texto, this.x + this.w / 2, this.y + this.h / 2);
}
clicado(mx, my) {
return mx > this.x && mx < this.x + this.w && my > this.y && my < this.y + this.h;
}
}
function mousePressed() {
if (tela === "inicio") {
if (botaoJogar.clicado(mouseX, mouseY)) iniciarJogo();
else if (botaoComo.clicado(mouseX, mouseY)) tela = "como";
} else if (tela === "como" || tela === "fim") {
if (botaoVoltar.clicado(mouseX, mouseY)) tela = "inicio";
}
}

function iniciarJogo() {
inicializarTratores();
inicializarMilhos();
tempoRestante = tempoJogo;
tela = "jogo";
}

function keyPressed() {
if (tela === "fim" && key === " ") {
tela = "inicio";
}
}
